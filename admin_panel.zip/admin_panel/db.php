<?php
$servername="localhost";
$dbname = "cashkingtest";
$username = "cashkingtest";
$password = "123456";

$link=mysqli_connect($servername,$username, $password,$dbname);

if(!$link)
{
    echo "error";
}

$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
?>
<?php

$demo = false; // change this to false for live and true for demo pannel.

?>